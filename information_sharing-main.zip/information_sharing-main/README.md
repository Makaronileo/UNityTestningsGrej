# information_sharing
 Models cooperation based on previous common experience
