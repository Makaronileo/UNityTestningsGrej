using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using FOODMEM;

public class agent : MonoBehaviour
{
    private GameObject home; private spawn_agents commons; private Vector3 home_pos;
    public FoodMemList food_memory;
    //private bool own_food, crashed, foraging;
    public bool exploit;
    public Rigidbody rb; private float fd, rot, speed, rotSpeed;

    //personality, to be used for genetic experiments, or for adapting personality based on interactions with other agents
    public float[] personality_vector;
    //health is used to keep track of how successful an agent was in a single round
    public int health = 0;
    private float foraging_time, buffer; public float time_to_forage = 5;

    // Start is called before the first frame update
    void Start()
    {
        home = GameObject.FindGameObjectWithTag("home");
        speed = 0.2f; rotSpeed = 1.5f;
        commons = home.GetComponent<spawn_agents>();
        food_memory = new FoodMemList();
        //buffer makes sure agents do not accidentally move while they forage
        buffer = -0.4f;
        time_to_forage += buffer;
        //foraging = false;
        //own_food = false;
        //crashed = false;
        home_pos = home.transform.position;
    }



    // Update is called once per frame
    void Update()
    {
        fd = 1;// Input.GetAxis("Vertical");
        rot = Random.Range(-5, 6); // Input.GetAxis("Horizontal");

    }



    //check what movements agent should engage in based on its state
    private void FixedUpdate()
    {

        foraging_time -= Time.fixedDeltaTime;


        // if there are active memories, follow the best one.
        if ( food_memory.hasactive() && exploit && foraging_time <= buffer )
        {
            transform.LookAt(food_memory.getbest().position);
        }

        if ( foraging_time <= buffer )
        {
            transform.Rotate(transform.up, rot * rotSpeed);
            transform.Translate(Vector3.forward * fd * speed);
        }
        if( transform.position.y < 0 )
        {
            float elevate = transform.position.y;
            transform.rotation = Quaternion.identity;
            transform.position = transform.position + new Vector3(0, -elevate + 0.1f, 0);

        }
    }




    //collide with home, food, or wall
    private void OnTriggerStay(Collider other)
    {
        if ( other.tag == "home" )
        {
            transform.Rotate(transform.up, 180);
            //if ( own_food )
            //{
            //    own_food = false;
            //    commons.communal_store += 1;
            //}   
        }
        // HOW MUCH FOOD DID I GET FROM FOODSOURCE X?
        if ( other.tag == "food" )
        {
            //transform.LookAt(home_pos);
            //transform.position = other.transform.position + transform.forward;
            if ( foraging_time <= 0 )
            {
                foodsource fs = other.gameObject.GetComponent<foodsource>();
                if ( fs.calories > 0 )
                {
                    food_memory.update_memory(fs.gameObject);
                    //Debug.Log("EATING");
                    fs.calories -= 1;
                    health += 1;
                    commons.communal_store += 1;
                    foraging_time = time_to_forage;
                    //Debug.Log("GOT SOME FOD");
                }
                else if ( food_memory.has_source(fs.gameObject) )
                {
                    food_memory.selectmemory_from_source(fs.gameObject).toggle_memory();
                    //Debug.Log("Toggled");
                }  
            }
        }
        if ( other.tag == "wall" )
        {
            transform.LookAt(home_pos);
        }
    }
    //make sure agents do not tip over
    private void OnTriggerExit(Collider other)
    {
        rb.angularVelocity = Vector3.zero;
    }


}






////check what movements agent should engage in based on its state
//private void FixedUpdate()
//{
//    if (own_food || crashed)
//    {
//        transform.LookAt(home_pos);
//    }

//    // if there are active memories, follow the best one.
//    if (food_memory.hasactive() && !own_food && exploit)
//    {
//        transform.LookAt(food_memory.getbest().position);
//    }
//    else if (!own_food)
//    {
//        transform.Rotate(transform.up, rot * rotSpeed);
//    }

//    //just move forward, perhaps need conditions??
//    transform.Translate(Vector3.forward * fd * speed);
//}






////collide with home, food, or wall
//private void OnTriggerStay(Collider other)
//{
//    if (other.tag == "home")
//    {
//        if (own_food)
//        {
//            own_food = false;
//            commons.communal_store += 1;
//        }
//    }
//    // HOW MUCH FOOD DID I GET FROM FOODSOURCE X?
//    if (other.tag == "food")
//    {
//        //transform.LookAt(home_pos);
//        //transform.position = other.transform.position + transform.forward;
//        if (!own_food)
//        {
//            foodsource fs = other.gameObject.GetComponent<foodsource>();
//            if (fs.calories > 0)
//            {
//                food_memory.update_memory(fs.gameObject);

//                fs.calories -= 1;
//                health += 1;
//                own_food = true;
//                //Debug.Log("GOT SOME FOD");
//            }
//            else if (food_memory.has_source(fs.gameObject))
//            {
//                food_memory.selectmemory_from_source(fs.gameObject).toggle_memory();
//                //Debug.Log("Toggled");
//            }
//        }
//    }
//    if (other.tag == "wall")
//    {
//        transform.LookAt(home_pos);
//    }
//}