﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using FOODMEM;

public class Pair
{
    public agent A, B;
    public float mu, sigma;
    
    public Pair(agent a, agent b, float m=0.5f, float s=0.1f)
    {
        mu = m; sigma = s;
        //make sure healthiest part is agent A
        if (b.health > a.health)
        {
            A = b;
            B = a;
        }
        else if (a.health >= b.health)
        {
            A = a;
            B = b;
        }
    }

    public void Interaction()
    {
        FoodMemList A_mem = A.food_memory;
        FoodMemList B_mem = B.food_memory;
        A_mem.sortsources(); B_mem.sortsources();

        float p_teach = A.personality_vector[0];
        float p_teach_2nd = A.personality_vector[1];
        float p_give_fish = A.personality_vector[2];
        float dissimilarity = 0;
        float max_dissimilarity = Mathf.Pow(A_mem.foodlist.Count, 2);
        

        //Look at every memory in A
        foreach (FoodMemo memo in A_mem.foodlist)
        {
            //the prescence of memory_A_n in B is not known
            bool same = false;
            //Compare present memory to memories in B
            foreach (FoodMemo compare in B_mem.foodlist)
            {
                //Indicate with bool same that memo_A_n is present in B
                if (memo.source == compare.source)
                {
                    same = true;
                    //Look at how each agent prioritizes the same food source
                    if ( same )
                    {
                        int A_ind, B_ind;
                        A_ind = A_mem.foodlist.IndexOf(memo);
                        B_ind = B_mem.foodlist.IndexOf(compare);
                        //get the absolute distance between items
                        dissimilarity += Mathf.Abs(A_ind - B_ind);
                        if ( dissimilarity > A_mem.foodlist.Count )
                        {
                            dissimilarity = A_mem.foodlist.Count;
                        }
                        //break in order to move on to next memory of A.
                        break;
                    }
                }
            }
            if ( !same )
            {
                //foreach finishes witout break - so memory_A_n did not exist in B
                dissimilarity += A_mem.foodlist.Count;
            }
        }
        dissimilarity /= max_dissimilarity;
        //Debug.Log("RATIO: " + dissimilarity);
        //NEW METHOD
        p_teach = AUC(dissimilarity);
        if ( dissimilarity > 1 )
        {
            Debug.Log(A);
            Debug.Log(B);
            A.GetComponent<Renderer>().material.SetColor("_Color", Color.red);
            B.GetComponent<Renderer>().material.SetColor("_Color", Color.yellow);
            Debug.Log("RATIO: " + dissimilarity);
            Debug.Log("p_teach: " + p_teach);
            Debug.Break();
        }

        

        ////OLD METHOD
        //p_teach = normal(dissimilarity);
        //Debug.Log("P_TEACH: " + p_teach);
        //float max_p_teach = normal(mu);
        //Debug.Log("MAX_TEACH: " + p_teach);
        //float threshold_val = Random.Range(0, max_p_teach);

        if ( A.food_memory.hasactive() && p_teach > Random.value )
        {
            FoodMemo A_lesson = A_mem.getbest();
            if ( A_lesson.self_taught )
            {
                B_mem.hear_about_source(A_lesson.source, A_mem.getbest().reward);
            }
            else//temporary
            {
                B_mem.hear_about_source(A_lesson.source, A_mem.getbest().reward);
            }
        }
    }

    

    public float AUC(float z, float delta=0.01f, float width=0.6f)
    {
        if (z > mu)
        {
            z -= (z - mu) * 2;
        }
        float y;
        float hi = mu + width;

        float two_sigma_squared = Mathf.Pow(2 * sigma, 2);
        float sqrt_two_pi = Mathf.Sqrt(2 * Mathf.PI);

        float area = 1;
        for ( float x = z; x<mu; x+=delta )
        //for ( float x = mu-width; x<mu+width; x+=delta ) //entire curve
        {
            
            y = Mathf.Pow(x - mu, 2);
            y = -y / two_sigma_squared;
            y = Mathf.Exp(y);
            y /=sigma;
            y /= sqrt_two_pi;
            y *= delta;
            area -= y*2;
        }
        //area *= 2;
        //Debug.Log("AREA: " + area);
        return area;
    }


    //public float normal(float x)
    //{
    //    float y = Mathf.Pow(x - mu, 2);
    //    y = -y / Mathf.Pow(2 * sigma, 2);
    //    //Debug.Log("heee: "+ y);
    //    y = Mathf.Exp(y);
    //    y = y / sigma;
    //    y = y / Mathf.Sqrt(2 * Mathf.PI);
    //    Debug.Log("HEEEE: " + y);
    //    return y;
    //}
}
