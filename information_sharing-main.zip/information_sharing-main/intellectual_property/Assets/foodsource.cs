using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class foodsource : MonoBehaviour
{
    public int calories, remember_cals;
    // Start is called before the first frame update
    void Start()
    {
        calories = Random.Range(5, 20);
        remember_cals = calories;
    }

    // Update is called once per frame
    void Update()
    {
        if ( calories <= 0 )
        {
            transform.GetComponent<Renderer>().material.SetColor("_Color", Color.black);
        }
    }

    public void refill()
    {
        calories = remember_cals;
        transform.GetComponent<Renderer>().material.SetColor("_Color", Color.green);
    }
}
