using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

public class spawn_agents : MonoBehaviour
{
    public GameObject agent_preFab;
    private GameObject scoreKeeper;
    public int no_agents, no_rows, no_days;
    public float communal_store, time;
    public float p_exploit, ideal_memory_overlap, sigma;
    //ideal_memory_overlap is similarity (value between 0-1) that gives highest likelihood of memory transfer.
    //sigma is the standard deviation of the memory overlap that is tested.
    private List<GameObject> agents;
    //private Text score;




    //Start is called before the first frame update
    void Start()
    {
        //p_exploit = 0.75f; ideal_memory_overlap = 0.6f; sigma = 0.75f;

        //Scorekeeper used to show number of food in communal_store
        scoreKeeper = GameObject.FindGameObjectWithTag("score");
        communal_store = 0;

        agents = new List<GameObject>();
        //spawn agents and keep them in list called "agents"
        if ( no_agents%no_rows == 0)
        {
            for (int i = 0; i < no_agents / no_rows; i++)
            {
                for (int j = 0; j < no_rows; j++)
                {
                    Vector3 pos = new Vector3(i, 0.5f, j);
                    agents.Add(Instantiate(agent_preFab, pos, Quaternion.identity));
                    
                }     
            }
        }
        //randomize personality at start of simulation (not currently relevant)
        foreach (GameObject agent in agents)
        {
            agent agentscript = agent.GetComponent<agent>();
            agentscript.personality_vector = new float[3];
            for ( int i=0; i<agentscript.personality_vector.Length; i++)
            {
                agentscript.personality_vector[i] = Random.value;
            }
        }
        //start at time 0 of day 0
        time = 0;
        no_days = 0;
    }






    // Update is called once per frame
    void Update()
    {
        scoreKeeper.GetComponent<Text>().text = communal_store.ToString();
        if ( time > 60 )
        {
            time = 0;
            sort_agents();
            agents_interact();
            replenish_food();
            no_days += 1;
        }

        if ( no_days > 10 )
        {
            //next_generation();
        }
    }


    //called at fixed interval to make sure time moves steadily
    private void FixedUpdate()
    {
        time += Time.fixedDeltaTime;
    }


    //order agents by how many points they have
    private void sort_agents()
    {
        agents.Sort((x, y) => y.GetComponent<agent>().health.CompareTo(x.GetComponent<agent>().health));
        agents[0].GetComponent<Renderer>().material.SetColor("_Color", Color.blue);
        communal_store = 0;
        foreach ( GameObject agent in agents )
        {
            agent agentscript = agent.GetComponent<agent>();
            agentscript.food_memory.activate_memories();
            
            if ( p_exploit > Random.value )
            {
                agentscript.exploit = true;
            }
            else
            {
                agentscript.exploit = false;
            }
        }
    }

    //resets all foodsources to their initial capacity
    private void replenish_food()
    {
        GameObject[] foodsources = GameObject.FindGameObjectsWithTag("food");
        foreach ( GameObject fs in foodsources)
        {
            fs.GetComponent<foodsource>().refill();
        }
    }



    //at the end of the day agents group into random pairs.
    //each pair settles which part has the most successful strategy - Pair.Interaction()
    //
    private void agents_interact()
    {
        //GENERATE PAIRS
        int range, sel;
        List<Pair> agent_pairs = new List<Pair>();
        List<GameObject> backup = new List<GameObject>(agents);

        //create pair and put it in list "agent_pairs"
        for (int i = 0; i < backup.Count; i+=2)
        {
            //how pair is selected..
            range = backup.Count;
            sel = Random.Range(0, range);
            GameObject A = backup[sel];
            backup.Remove(A);
            range = backup.Count;
            sel = Random.Range(0, range);
            GameObject B = backup[sel];
            backup.Remove(B);

            //pair is created and listed
            Pair p = new Pair(A.GetComponent<agent>(), B.GetComponent<agent>(), ideal_memory_overlap, sigma);
            agent_pairs.Add(p);
        }

        //have each pair interact so they can potentially exchange knowledge
        foreach ( Pair p in agent_pairs )
        {
            p.Interaction();
        }

        //reset each agents health AFTER they are finished interacting, since health is indicator of most successful strategy
        foreach ( GameObject agent in agents )
        {
            agent agentscript = agent.GetComponent<agent>();
            agentscript.health = 0;
            agentscript.food_memory.normalize_rewards();
        }
    }





    //not currently used. supposed to generate new genotypes for genetic simulations
    private void next_generation()
    {
        List<GameObject> nextgen = new List<GameObject>();
        sort_agents();
        // use communal store to determine how many agents can be added to next generation;
        
        foreach (GameObject agent in agents)
        {
            agent agentscript = agent.GetComponent<agent>();
            if ( agentscript.health > 10 )
            {
                agentscript.food_memory.wipe_memory();
                agentscript.health = 0;
                nextgen.Add(agent);
            }
        }


    }
}
