﻿using System;
using System.Linq;
using UnityEngine;
using System.Collections.Generic;

namespace FOODMEM
{
    [System.Serializable]
    public class FoodMemo
    {
        public Vector3 position;
        public float reward;
        public bool active;
        public bool self_taught, relearned;
        public GameObject source;

        public FoodMemo(Vector3 pos)
        {
            active = false;
            reward = 0;
            position = pos;
            self_taught = true;
            relearned = false;
        }

        public void memory_reward(bool strengthen=true)
        {
            if ( strengthen )
            {
                reward += 1;
            }
            else
            {
                reward = 0;
            }            
        }

        //at the moment this deactivates the present memory.
        public void toggle_memory(bool reset=false)
        {
            if ( active )
            {
                active = false;
            }
            else
            {
                active = reset;
            }
        }
    }







//-----------------------------------------------------------------------------
//

    [System.Serializable]
    public class FoodMemList
    {
        public List<FoodMemo> foodlist;
        private List<GameObject> sources;

        public FoodMemList()
        {
            foodlist = new List<FoodMemo>();
        }


        public void wipe_memory()
        {
            foodlist.Clear();
        }


        //checks if agent has looked at all of its known food locations
        public bool hasactive()
        {
            foreach ( FoodMemo memo in foodlist )
            {
                if ( memo.active )
                {
                    return true;
                }
            }
            return false;
        }




        //if foodsource is already in memory, strengthen, otherwise, add.
        public void update_memory(GameObject foodsource)
        {
            //recall known sources
            sources = new List<GameObject>();
            foreach (FoodMemo memo in foodlist)
            {
                sources.Add(memo.source);
            }
            //already known source..
            if ( sources.Contains(foodsource) )
            {
                selectmemory_from_source(foodsource).memory_reward();
            }
            //new source!
            else
            {
                FoodMemo memo = new FoodMemo(foodsource.transform.position);
                memo.source = foodsource;
                memo.active = true;
                memo.self_taught = true;
                memo.memory_reward();

                foodlist.Add(memo);
            } 
        }




        // learn about specific foodsource from other agent.
        public void hear_about_source(GameObject foodsource, float reward)
        {
            // recall all known sources
            sources = new List<GameObject>();
            foreach (FoodMemo memo in foodlist)
            {
                sources.Add(memo.source);
            }
            // Already know
            if ( sources.Contains(foodsource) )
            {
                if (selectmemory_from_source(foodsource).reward < reward )
                {
                    selectmemory_from_source(foodsource).reward = reward;
                    selectmemory_from_source(foodsource).relearned = true;
                }
                
            }
            else
            {
                FoodMemo memo = new FoodMemo(foodsource.transform.position);
                memo.source = foodsource;
                memo.reward = reward;
                memo.active = true;
                memo.self_taught = false;
                memo.memory_reward();

                foodlist.Add(memo);
            }
        }



        // return the memory associated with a specific foodsource
        public bool has_source(GameObject foodsource)
        {
            sources = new List<GameObject>();
            foreach (FoodMemo memo in foodlist)
            {
                sources.Add(memo.source);
            }
            // Already know
            if (sources.Contains(foodsource))
            {
                //Debug.Log("KNOWN");
                return true;
            }
            else
            {
                //Debug.Log("UNKNOWN");
                return false; 
            }
        }




        // return the memory associated with a specific foodsource
        public FoodMemo selectmemory_from_source(GameObject foodsource)
        {
            foreach (FoodMemo memo in foodlist)
            {
                if ( memo.source == foodsource )
                {
                    return memo;
                }
            }
            //will not happen
            Debug.Log("Something is probably wrong");
            return foodlist[0];
        }




        //return (active/considered) foodsource associated with most reward
        public FoodMemo getbest()
        {
            foodlist.Sort((x, y) => y.reward.CompareTo(x.reward));
            foreach ( FoodMemo memo in foodlist )
            {
                if ( memo.active )
                {
                    return memo;
                }
            }
            Debug.Log("NÅGOT FEL");
            return new FoodMemo(Vector3.zero);
        }

        public void sortsources()
        {
            foodlist.Sort((x, y) => y.reward.CompareTo(x.reward));
        }


        //is called when a new day begins to alert agents to all their known sources
        public void activate_memories()
        {
            foreach ( FoodMemo memo in foodlist )
            {
                memo.active = true;
            }
        }


        public void normalize_rewards()
        {  
            if (foodlist.Count > 0)
            {
                float max_reward = 1;
                max_reward = foodlist.Max(x => x.reward);
                foreach (FoodMemo memo in foodlist)
                {
                    memo.reward /= max_reward;
                }
            } 
        }

        public void reset_rewards()
        {
            foreach (FoodMemo memo in foodlist)
            {
                memo.memory_reward(false);
            }
        }

        public void sleep()
        {

        }

    }





}

